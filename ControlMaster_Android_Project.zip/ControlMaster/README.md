# Control Master — Android starter project

Versión: 0.1.0

## Qué incluye
- Interfaz Android nativa con Kotlin y Jetpack Compose.
- Panel oscuro de administrador.
- Lista de hasta cinco dispositivos de demostración.
- Pantallas de detalle y avisos informativos.
- Diseño preparado para añadir vinculación consentida.

## Importante
Esta primera versión es una **maqueta funcional de interfaz**. Los celulares, estados de conexión y porcentajes de batería son datos de ejemplo. No realiza rastreo GPS real, no bloquea teléfonos y no activa alarmas en otros dispositivos.

Las siguientes etapas deben implementar:
1. Inicio de sesión y autenticación segura.
2. Aplicación/servicio compañero en cada celular.
3. Invitación por QR o código de un solo uso y aceptación explícita.
4. Compartición visible de ubicación, con controles para pausar o revocar.
5. Notificaciones y sincronización mediante un backend seguro.
6. Funciones de sonido y administración compatibles con las políticas y permisos de Android. El bloqueo remoto no debe eludir el control del propietario ni las protecciones del sistema.

## Cómo abrir y generar el APK
1. Instala Android Studio en una computadora.
2. Descomprime este proyecto.
3. En Android Studio, selecciona **Open** y elige la carpeta `ControlMaster`.
4. Espera a que termine la sincronización de Gradle.
5. Usa **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio mostrará la ubicación del APK generado.

Requisitos: Android Studio reciente, JDK 17 y conexión a internet durante la primera sincronización de dependencias.

## Identificadores
- Application ID: `com.controlmaster.app`
- Min SDK: 26
- Target SDK: 35


## Compilar el APK desde un celular usando GitHub Actions
Este proyecto incluye `.github/workflows/android.yml` para compilar automáticamente el APK en GitHub Actions.

1. En el navegador del celular, inicia sesión o crea una cuenta en GitHub.
2. Crea un repositorio nuevo y sube el contenido completo de esta carpeta.
3. Abre la pestaña **Actions** del repositorio y ejecuta **Build Control Master APK** (o espera a que termine tras subir a `main`).
4. Cuando el proceso termine correctamente, abre la ejecución y descarga el artefacto **ControlMaster-debug-apk**.
5. Descomprime el artefacto y abre `app-debug.apk` en Android para instalarlo.

Android puede pedir que permitas temporalmente instalar aplicaciones desde el navegador o gestor de archivos que uses. Instala solo el APK que tú mismo hayas generado desde tu repositorio.

La compilación remota requiere internet y una cuenta de GitHub. Este flujo genera un APK de depuración para pruebas, no una versión publicada en Play Store.
