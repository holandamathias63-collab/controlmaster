package com.controlmaster.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF152238)
private val Panel2 = Color(0xFF1D2D45)
private val Accent = Color(0xFF55D6A5)
private val Blue = Color(0xFF66A7FF)
private val Muted = Color(0xFF9AABC2)

data class Device(val name: String, val status: String, val battery: Int, val shared: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ControlMasterApp() }
    }
}

@Composable
fun ControlMasterApp() {
    var devices by remember {
        mutableStateOf(
            listOf(
                Device("Celular principal", "En línea · Ejemplo", 86, true),
                Device("Celular 2", "En línea · Ejemplo", 64, true),
                Device("Celular 3", "Sin conexión · Ejemplo", 31, false)
            )
        )
    }
    var selected by remember { mutableStateOf<Device?>(null) }
    var dialog by remember { mutableStateOf<String?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            secondary = Blue, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (selected != null) {
                DeviceDetail(selected!!, onBack = { selected = null }) { dialog = it }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(18.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, null, tint = Accent, modifier = Modifier.size(32.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("CONTROL MASTER", fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                                Text("Panel de administración", color = Muted, fontSize = 12.sp)
                            }
                            Surface(color = Color(0xFF173D35), shape = RoundedCornerShape(30.dp)) {
                                Text("ADMIN", color = Accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("VINCULADOS", "${devices.size}/5", Icons.Default.Smartphone, Modifier.weight(1f))
                            StatCard("EN LÍNEA", "${devices.count { it.status.startsWith("En línea") }}", Icons.Default.Wifi, Modifier.weight(1f))
                        }
                    }
                    item {
                        SectionTitle("Mis dispositivos", "Hasta 5 celulares")
                    }
                    items(devices) { device ->
                        DeviceCard(device) { selected = device }
                    }
                    item {
                        Button(
                            onClick = { dialog = "Vincular celular: en la siguiente etapa añadiremos invitación segura mediante QR y aceptación en el otro dispositivo." },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.AddLink, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Vincular otro celular", fontWeight = FontWeight.Bold)
                        }
                    }
                    item {
                        SectionTitle("Herramientas", "Acciones disponibles según permisos")
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ToolTile("Ubicación", Icons.Default.LocationOn, Blue, Modifier.weight(1f)) {
                                dialog = "La ubicación GPS se añadirá cuando el dispositivo vinculado acepte y active explícitamente el permiso de ubicación."
                            }
                            ToolTile("Hacer sonar", Icons.Default.NotificationsActive, Color(0xFFFFC66D), Modifier.weight(1f)) {
                                dialog = "La función de alarma remota se añadirá con confirmación visible en el dispositivo receptor."
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ToolTile("Batería", Icons.Default.BatteryFull, Accent, Modifier.weight(1f)) {
                                dialog = "El nivel de batería mostrado en esta versión es de demostración."
                            }
                            ToolTile("Bloqueo", Icons.Default.Lock, Color(0xFFC4A7FF), Modifier.weight(1f)) {
                                dialog = "El bloqueo remoto requiere una implementación compatible y autorización especial del propietario o administrador del dispositivo."
                            }
                        }
                    }
                    item {
                        Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.VerifiedUser, null, tint = Accent)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text("Privacidad y autorización", fontWeight = FontWeight.Bold)
                                    Text("Cada celular debe aceptar la vinculación y puede dejar de compartir su ubicación. Esta versión usa datos de ejemplo y todavía no realiza rastreo real.", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Text("CONTROL MASTER · versión 0.1.0", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth())
                    }
                }
            }

            if (dialog != null) {
                AlertDialog(
                    onDismissRequest = { dialog = null },
                    containerColor = Panel2,
                    title = { Text("Control Master") },
                    text = { Text(dialog!!) },
                    confirmButton = {
                        TextButton(onClick = { dialog = null }) { Text("Entendido", color = Accent) }
                    }
                )
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(10.dp))
            Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun DeviceCard(device: Device, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = Panel, shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Panel2, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(46.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Smartphone, null, tint = Blue, modifier = Modifier.size(25.dp))
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(device.name, fontWeight = FontWeight.SemiBold)
                Text(device.status, color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.BatteryStd, null, tint = Accent, modifier = Modifier.size(14.dp))
                    Text(" ${device.battery}% · muestra", color = Muted, fontSize = 10.sp)
                }
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
fun ToolTile(title: String, icon: ImageVector, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(modifier.clickable(onClick = onClick), color = Panel, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.Start) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(23.dp))
            Spacer(Modifier.height(9.dp))
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
    }
}

@Composable
fun DeviceDetail(device: Device, onBack: () -> Unit, onAction: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White) }
            Text(device.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Icon(Icons.Default.Smartphone, null, tint = Blue, modifier = Modifier.size(38.dp))
                Spacer(Modifier.height(10.dp))
                Text(device.status, color = Muted)
                Text("Batería: ${device.battery}% (dato de ejemplo)", fontWeight = FontWeight.SemiBold)
                Text("Compartición de ubicación: ${if (device.shared) "autorizada en la maqueta" else "no disponible en la maqueta"}", color = Muted, fontSize = 12.sp)
            }
        }
        Text("Acciones", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        listOf(
            Triple("Consultar ubicación", Icons.Default.LocationOn, "La ubicación real necesita permiso explícito y conexión con el celular."),
            Triple("Hacer sonar alarma", Icons.Default.NotificationsActive, "La alarma remota todavía no está conectada."),
            Triple("Solicitar bloqueo", Icons.Default.Lock, "El bloqueo requiere permisos de administración del dispositivo y confirmación.")
        ).forEach { (label, icon, message) ->
            OutlinedButton(onClick = { onAction(message) }, modifier = Modifier.fillMaxWidth()) {
                Icon(icon, null)
                Spacer(Modifier.width(8.dp))
                Text(label)
            }
        }
        Text("Las acciones de esta versión son demostrativas; no ejecutan comandos en otros teléfonos.", color = Muted, fontSize = 12.sp)
    }
}
